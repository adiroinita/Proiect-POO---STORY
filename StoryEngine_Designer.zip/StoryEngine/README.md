# StoryEngine — Motor de poveste interactiv

## Structura soluției

```
StoryEngine.sln
├── Story.Model          ← entități de date (fără dependențe externe)
│   ├── StoryDefinition.cs
│   ├── StoryBlock.cs
│   ├── DecisionDefinition.cs
│   ├── StatePropertyDefinition.cs
│   ├── Conditions/ConditionNode.cs   ← AST: COMPARISON, AND, OR
│   └── Effects/EffectDefinition.cs
│
├── Story.Engine         ← logica pură de joc
│   ├── GameState.cs
│   ├── GameEngine.cs
│   ├── ConditionEvaluator.cs
│   └── StoryValidator.cs
│
├── Story.Persistence    ← JSON + ZIP
│   └── StoryRepository.cs
│
├── Story.Player         ← aplicație WinForms de citire
│   ├── Program.cs
│   ├── MainForm.cs
│   ├── MainForm.Designer.cs
│   ├── MainForm.Hud.cs
│   └── GameEngineExtended.cs
│
└── Story.Editor         ← aplicație WinForms de editare
    ├── Program.cs
    ├── EditorForm.cs
    ├── EditorForm.Designer.cs
    ├── EditPanels.cs       ← MetadataPanel, PropertyPanel, BlockPanel, DecisionDialog
    └── DarkTheme.cs
```

## Cerințe

- Visual Studio Community 2022 (sau mai nou)
- .NET 8 SDK (Windows)
- Target framework: `net8.0-windows`

## Pași de pornire

1. Deschide `StoryEngine.sln` în Visual Studio.
2. Build → Build Solution (Ctrl+Shift+B).
3. Setează `Story.Editor` sau `Story.Player` ca **Startup Project**.
4. Run (F5).

## Flux de test rapid

1. Pornește **Story.Editor**
2. Creează o poveste nouă sau deschide `sample_story.json` (convertit manual la ZIP cu story.json înăuntru)
3. Salvează ca `test.zip`
4. Pornește **Story.Player** → Fișier → Deschide poveste → selectează `test.zip`

## Creare ZIP de test din linie de comandă (PowerShell)

```powershell
# Dintr-un folder care conține story.json și images/
Compress-Archive -Path story.json, images -DestinationPath test_story.zip
```

## Note de implementare

### Polimorfism JSON (ConditionNode)
Folosit `[JsonPolymorphic]` din .NET 7+.
Dacă folosești .NET 6, înlocuiește cu Newtonsoft.Json:
```csharp
// În JsonOptions:
new JsonSerializerSettings {
    TypeNameHandling = TypeNameHandling.Auto
}
```

### RefreshHud în MainForm
`MainForm.cs` conține un stub `RefreshHud()`.
Metoda completă e în `MainForm.Hud.cs` ca `RefreshHudFull()`.

**Pași de integrare:**
1. În `MainForm.cs`, schimbă `private GameEngine? _engine` → `private GameEngineExtended? _engine`
2. La creare: `_engine = new GameEngineExtended(story);`
3. În `RefreshView()`, înlocuiește `RefreshHud()` cu `RefreshHudFull()`

### Imagini
La salvare ZIP din editor, colectați imaginile astfel:
```csharp
var images = new Dictionary<string, byte[]>();
foreach (var block in _story.Blocks)
    if (block.BackgroundImage != null)
        images[block.BackgroundImage] = File.ReadAllBytes(localPath);
_repo.SaveToZip(_story, zipPath, images);
```
