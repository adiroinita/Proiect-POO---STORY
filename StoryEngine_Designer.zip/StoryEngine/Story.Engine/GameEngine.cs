using System;
using System.Collections.Generic;
using System.Linq;
using Story.Model;
using Story.Model.Effects;

namespace Story.Engine
{

    public class GameEngine
    {
        private readonly StoryDefinition _story;
        private readonly Dictionary<string, StoryBlock> _blockMap;
        private readonly Dictionary<string, StatePropertyDefinition> _propMap;

        public GameState State { get; private set; }

        public GameEngine(StoryDefinition story)
        {
            _story = story ?? throw new ArgumentNullException(nameof(story));

            _blockMap = story.Blocks.ToDictionary(b => b.Id, b => b);
            _propMap  = story.Properties.ToDictionary(p => p.Key, p => p);

            State = BuildInitialState();
        }

        private GameState BuildInitialState()
        {
            var state = new GameState { CurrentBlockId = _story.StartBlock };
            foreach (var prop in _story.Properties)
                state.Properties[prop.Key] = prop.Initial;
            return state;
        }

        public StoryBlock CurrentBlock =>
            _blockMap.TryGetValue(State.CurrentBlockId, out var b)
                ? b
                : throw new InvalidOperationException($"Bloc inexistent: '{State.CurrentBlockId}'");

        public bool IsGameOver => CurrentBlock.IsFinal || GetAvailableDecisions().Count == 0;

        public List<DecisionDefinition> GetAvailableDecisions()
        {
            return CurrentBlock.Decisions
                .Where(d => ConditionEvaluator.Evaluate(d.Condition, State.Properties))
                .ToList();
        }

        public string ApplyDecision(DecisionDefinition decision)
        {
            if (decision is null) throw new ArgumentNullException(nameof(decision));

            ApplyEffects(decision.Effects);

            string? redirect = CheckRedirects();
            if (redirect is not null)
            {
                State.CurrentBlockId = redirect;
                return redirect;
            }

            State.CurrentBlockId = decision.TargetBlock;
            return decision.TargetBlock;
        }

        public void Restart() => State = BuildInitialState();

        public void LoadState(GameState savedState) =>
            State = savedState ?? throw new ArgumentNullException(nameof(savedState));

        private void ApplyEffects(List<EffectDefinition> effects)
        {
            foreach (var effect in effects)
            {
                if (!State.Properties.ContainsKey(effect.Property))
                    throw new InvalidOperationException(
                        $"Proprietatea '{effect.Property}' nu există în stare.");

                if (!_propMap.TryGetValue(effect.Property, out var propDef))
                    throw new InvalidOperationException(
                        $"Definiția pentru '{effect.Property}' lipsește.");

                double current = State.Properties[effect.Property];
                double newValue = effect.Type switch
                {
                    EffectType.ADD => current + effect.Value,
                    EffectType.SET => effect.Value,
                    _ => throw new InvalidOperationException($"EffectType necunoscut: {effect.Type}")
                };

                State.Properties[effect.Property] =
                    Math.Max(propDef.Min, Math.Min(propDef.Max, newValue));
            }
        }

        private string? CheckRedirects()
        {
            foreach (var propDef in _story.Properties)
            {
                if (!State.Properties.TryGetValue(propDef.Key, out double val)) continue;

                if (val <= propDef.Min && propDef.OnMinBlock is not null)
                    return propDef.OnMinBlock;

                if (val >= propDef.Max && propDef.OnMaxBlock is not null)
                    return propDef.OnMaxBlock;
            }
            return null;
        }
    }
}
