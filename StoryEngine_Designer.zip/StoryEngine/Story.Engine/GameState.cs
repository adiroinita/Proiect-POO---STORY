using System.Collections.Generic;

namespace Story.Engine
{

    public class GameState
    {
        
        public string CurrentBlockId { get; set; } = string.Empty;

        public Dictionary<string, double> Properties { get; set; } = new();

        public GameState Clone()
        {
            return new GameState
            {
                CurrentBlockId = this.CurrentBlockId,
                Properties = new Dictionary<string, double>(this.Properties)
            };
        }
    }
}
