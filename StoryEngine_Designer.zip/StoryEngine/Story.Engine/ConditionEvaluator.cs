using System;
using System.Collections.Generic;
using Story.Model.Conditions;

namespace Story.Engine
{

    public static class ConditionEvaluator
    {

        public static bool Evaluate(ConditionNode? node, Dictionary<string, double> state)
        {
            if (node is null) return true;

            return node switch
            {
                ComparisonNode cmp => EvaluateComparison(cmp, state),
                AndNode and        => EvaluateAnd(and, state),
                OrNode or          => EvaluateOr(or, state),
                _ => throw new InvalidOperationException($"Tip necunoscut de nod: {node.GetType().Name}")
            };
        }

        private static bool EvaluateComparison(ComparisonNode node, Dictionary<string, double> state)
        {
            if (!state.TryGetValue(node.Property, out double current))
                throw new KeyNotFoundException(
                    $"Proprietatea '{node.Property}' nu există în starea curentă.");

            return node.Operator switch
            {
                "<"  => current <  node.Value,
                "<=" => current <= node.Value,
                ">"  => current >  node.Value,
                ">=" => current >= node.Value,
                "==" => Math.Abs(current - node.Value) < 1e-9,
                "!=" => Math.Abs(current - node.Value) >= 1e-9,
                _ => throw new InvalidOperationException($"Operator necunoscut: '{node.Operator}'")
            };
        }

        private static bool EvaluateAnd(AndNode node, Dictionary<string, double> state)
        {
            foreach (var child in node.Conditions)
                if (!Evaluate(child, state)) return false;
            return true;
        }

        private static bool EvaluateOr(OrNode node, Dictionary<string, double> state)
        {
            foreach (var child in node.Conditions)
                if (Evaluate(child, state)) return true;
            return false;
        }
    }
}
