using System.Collections.Generic;
using System.Linq;
using Story.Model;
using Story.Model.Conditions;

namespace Story.Engine
{

    public static class StoryValidator
    {
        public static List<string> Validate(StoryDefinition story)
        {
            var errors = new List<string>();
            if (story is null) { errors.Add("Povestea este null."); return errors; }

            ValidateMetadata(story, errors);
            ValidateProperties(story, errors);
            ValidateBlocks(story, errors);

            return errors;
        }

        private static void ValidateMetadata(StoryDefinition story, List<string> errors)
        {
            if (string.IsNullOrWhiteSpace(story.Title))
                errors.Add("Titlul poveștii este gol.");

            if (string.IsNullOrWhiteSpace(story.StartBlock))
                errors.Add("StartBlock nu este setat.");
            else if (story.Blocks.All(b => b.Id != story.StartBlock))
                errors.Add($"StartBlock '{story.StartBlock}' nu există în lista de blocuri.");
        }

        private static void ValidateProperties(StoryDefinition story, List<string> errors)
        {
            var keys = new HashSet<string>();
            foreach (var prop in story.Properties)
            {
                if (string.IsNullOrWhiteSpace(prop.Key))
                { errors.Add("O proprietate are cheia goală."); continue; }

                if (!keys.Add(prop.Key))
                    errors.Add($"Proprietatea '{prop.Key}' este duplicată.");

                if (prop.Min > prop.Max)
                    errors.Add($"'{prop.Key}': min ({prop.Min}) > max ({prop.Max}).");

                if (prop.Initial < prop.Min || prop.Initial > prop.Max)
                    errors.Add($"'{prop.Key}': initial ({prop.Initial}) este în afara [min,max].");

                var blockIds = story.Blocks.Select(b => b.Id).ToHashSet();

                if (prop.OnMinBlock is not null && !blockIds.Contains(prop.OnMinBlock))
                    errors.Add($"'{prop.Key}'.onMinBlock='{prop.OnMinBlock}' nu există.");

                if (prop.OnMaxBlock is not null && !blockIds.Contains(prop.OnMaxBlock))
                    errors.Add($"'{prop.Key}'.onMaxBlock='{prop.OnMaxBlock}' nu există.");
            }
        }

        private static void ValidateBlocks(StoryDefinition story, List<string> errors)
        {
            var blockIds = story.Blocks.Select(b => b.Id).ToHashSet();
            var propKeys = story.Properties.Select(p => p.Key).ToHashSet();
            var seenIds  = new HashSet<string>();

            foreach (var block in story.Blocks)
            {
                if (string.IsNullOrWhiteSpace(block.Id))
                { errors.Add("Un bloc are id-ul gol."); continue; }

                if (!seenIds.Add(block.Id))
                    errors.Add($"Blocul '{block.Id}' este duplicat.");

                foreach (var dec in block.Decisions)
                {
                    if (string.IsNullOrWhiteSpace(dec.TargetBlock))
                        errors.Add($"[{block.Id}] O decizie nu are TargetBlock setat.");
                    else if (!blockIds.Contains(dec.TargetBlock))
                        errors.Add($"[{block.Id}] TargetBlock='{dec.TargetBlock}' nu există.");

                    if (dec.Condition is not null)
                        ValidateConditionNode(dec.Condition, propKeys, block.Id, errors);

                    foreach (var eff in dec.Effects)
                        if (!propKeys.Contains(eff.Property))
                            errors.Add($"[{block.Id}] Efectul referă proprietatea inexistentă '{eff.Property}'.");
                }
            }
        }

        private static void ValidateConditionNode(
            ConditionNode node, HashSet<string> propKeys, string blockId, List<string> errors)
        {
            switch (node)
            {
                case ComparisonNode cmp:
                    if (!propKeys.Contains(cmp.Property))
                        errors.Add($"[{blockId}] Condiție: proprietatea '{cmp.Property}' nu există.");
                    break;
                case AndNode and:
                    foreach (var c in and.Conditions)
                        ValidateConditionNode(c, propKeys, blockId, errors);
                    break;
                case OrNode or:
                    foreach (var c in or.Conditions)
                        ValidateConditionNode(c, propKeys, blockId, errors);
                    break;
            }
        }
    }
}
