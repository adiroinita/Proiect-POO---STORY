using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Story.Model;

namespace Story.Persistence
{

    public class StoryRepository
    {
        private const string StoryJsonEntry = "story.json";
        private const string ImagesFolder   = "images/";

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented              = true,
            DefaultIgnoreCondition     = JsonIgnoreCondition.WhenWritingNull,
            PropertyNameCaseInsensitive = true,
            Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase, allowIntegerValues: false) }
        };

        public StoryDefinition LoadFromZip(string zipPath)
        {
            if (!File.Exists(zipPath))
                throw new FileNotFoundException($"Fișierul nu există: {zipPath}");

            using var zip = ZipFile.OpenRead(zipPath);
            var entry = zip.GetEntry(StoryJsonEntry)
                ?? throw new InvalidDataException("Arhiva nu conține story.json.");

            using var stream = entry.Open();
            using var reader = new StreamReader(stream, Encoding.UTF8);
            string json = reader.ReadToEnd();

            return JsonSerializer.Deserialize<StoryDefinition>(json, JsonOptions)
                ?? throw new InvalidDataException("story.json nu a putut fi deserializat.");
        }

        public byte[]? LoadImage(string zipPath, string relativePath)
        {
            using var zip = ZipFile.OpenRead(zipPath);
            var entry = zip.GetEntry(relativePath);
            if (entry is null) return null;

            using var stream = entry.Open();
            using var ms = new MemoryStream();
            stream.CopyTo(ms);
            return ms.ToArray();
        }

        public void SaveToZip(
            StoryDefinition story,
            string zipPath,
            Dictionary<string, byte[]>? imageFiles = null)
        {
            
            using var ms = new MemoryStream();

            using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, leaveOpen: true))
            {
                
                string json = JsonSerializer.Serialize(story, JsonOptions);
                var jsonEntry = zip.CreateEntry(StoryJsonEntry, CompressionLevel.Optimal);
                using (var w = new StreamWriter(jsonEntry.Open(), Encoding.UTF8))
                    w.Write(json);

                if (imageFiles is not null)
                {
                    foreach (var (relativePath, data) in imageFiles)
                    {
                        
                        string entryName = relativePath.Replace('\\', '/');
                        var imgEntry = zip.CreateEntry(entryName, CompressionLevel.Optimal);
                        using var imgStream = imgEntry.Open();
                        imgStream.Write(data, 0, data.Length);
                    }
                }
            }

            File.WriteAllBytes(zipPath, ms.ToArray());
        }

        public string ExtractToTempDir(string zipPath)
        {
            string tempDir = Path.Combine(Path.GetTempPath(), "StoryEditor_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tempDir);
            ZipFile.ExtractToDirectory(zipPath, tempDir, overwriteFiles: true);
            return tempDir;
        }

        public void PackFromDir(string sourceDir, string zipPath)
        {
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(sourceDir, zipPath, CompressionLevel.Optimal, includeBaseDirectory: false);
        }

        public void SaveGameState(Story.Engine.GameState state, string filePath)
        {
            string json = JsonSerializer.Serialize(state, JsonOptions);
            File.WriteAllText(filePath, json, Encoding.UTF8);
        }

        public Story.Engine.GameState LoadGameState(string filePath)
        {
            string json = File.ReadAllText(filePath, Encoding.UTF8);
            return JsonSerializer.Deserialize<Story.Engine.GameState>(json, JsonOptions)
                ?? throw new InvalidDataException("Fișierul de stare nu a putut fi citit.");
        }
    }
}
