using System.Collections.Generic;

namespace Story.Model
{

    public class StoryDefinition
    {
        public string Title { get; set; } = string.Empty;
        public string StartBlock { get; set; } = string.Empty;
        public List<StatePropertyDefinition> Properties { get; set; } = new();
        public List<StoryBlock> Blocks { get; set; } = new();
    }
}
