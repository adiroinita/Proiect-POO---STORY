namespace Story.Model.Effects
{

    public enum EffectType
    {
        
        ADD,

        SET
    }

    public class EffectDefinition
    {
        public EffectType Type { get; set; } = EffectType.ADD;

        public string Property { get; set; } = string.Empty;

        public double Value { get; set; }
    }
}
