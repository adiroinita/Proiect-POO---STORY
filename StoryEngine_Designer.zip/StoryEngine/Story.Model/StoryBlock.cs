using System.Collections.Generic;

namespace Story.Model
{

    public class StoryBlock
    {
        
        public string Id { get; set; } = string.Empty;

        public string Text { get; set; } = string.Empty;

        public bool IsFinal { get; set; } = false;

        public string? BackgroundImage { get; set; }

        public List<DecisionDefinition> Decisions { get; set; } = new();
    }
}
