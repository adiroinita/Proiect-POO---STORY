using System.Collections.Generic;
using Story.Model.Conditions;
using Story.Model.Effects;

namespace Story.Model
{

    public class DecisionDefinition
    {
        
        public string Text { get; set; } = string.Empty;

        public string TargetBlock { get; set; } = string.Empty;

        public string? Icon { get; set; }

        public ConditionNode? Condition { get; set; }

        public List<EffectDefinition> Effects { get; set; } = new();
    }
}
