using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Story.Model.Conditions
{

    [JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
    [JsonDerivedType(typeof(ComparisonNode), "COMPARISON")]
    [JsonDerivedType(typeof(AndNode),        "AND")]
    [JsonDerivedType(typeof(OrNode),         "OR")]
    public abstract class ConditionNode { }

    public class ComparisonNode : ConditionNode
    {
        
        public string Property { get; set; } = string.Empty;

        public string Operator { get; set; } = "==";

        public double Value { get; set; }
    }

    public class AndNode : ConditionNode
    {
        public List<ConditionNode> Conditions { get; set; } = new();
    }

    public class OrNode : ConditionNode
    {
        public List<ConditionNode> Conditions { get; set; } = new();
    }
}
