namespace Story.Model
{

    public class StatePropertyDefinition
    {
        
        public string Key { get; set; } = string.Empty;

        public string HudLabel { get; set; } = string.Empty;

        public double Min { get; set; } = 0;
        public double Max { get; set; } = 100;
        public double Initial { get; set; } = 0;

        public bool VisibleInHud { get; set; } = false;

        public int HudOrder { get; set; } = 99;

        public string? OnMinBlock { get; set; }

        public string? OnMaxBlock { get; set; }
    }
}
