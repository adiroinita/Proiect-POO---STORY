using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Story.Engine;
using Story.Model;

namespace Story.Player
{

    public class GameEngineExtended : GameEngine
    {
        public StoryDefinition Story { get; }

        public GameEngineExtended(StoryDefinition story) : base(story)
        {
            Story = story;
        }
    }
}
