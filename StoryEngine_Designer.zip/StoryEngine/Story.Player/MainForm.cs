using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Story.Engine;
using Story.Model;
using Story.Persistence;

namespace Story.Player
{

    public partial class MainForm : Form
    {

        private GameEngineExtended? _engine;
        private StoryRepository   _repo        = new();
        private string            _currentZip  = string.Empty;
        private Dictionary<string, Image> _imageCache = new();

        private MenuStrip         menuStrip     = new();
        private Panel             pnlTop        = new();
        private Label             lblTitle      = new();
        private FlowLayoutPanel   pnlHud        = new();
        private PictureBox        picBackground = new();
        private RichTextBox       rtbText       = new();
        private FlowLayoutPanel   pnlDecisions  = new();
        private Label             lblBlockId    = new();

        public MainForm()
        {
            InitializeComponent();
            BuildUi();
            ShowWelcome();
        }

        private void BuildUi()
        {
            
            Text            = "Story Player";
            MinimumSize     = new Size(800, 650);
            Size            = new Size(900, 700);
            BackColor       = Color.FromArgb(30, 30, 30);
            ForeColor       = Color.WhiteSmoke;
            StartPosition   = FormStartPosition.CenterScreen;

            BuildMenu();

            pnlTop.Dock        = DockStyle.Top;
            pnlTop.Height      = 60;
            pnlTop.BackColor   = Color.FromArgb(20, 20, 20);
            pnlTop.Padding     = new Padding(10, 5, 10, 5);

            lblTitle.AutoSize  = false;
            lblTitle.Dock      = DockStyle.Left;
            lblTitle.Width     = 350;
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            lblTitle.Font      = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.Gold;
            lblTitle.Text      = "Story Player";

            pnlHud.Dock      = DockStyle.Fill;
            pnlHud.FlowDirection = FlowDirection.LeftToRight;
            pnlHud.WrapContents  = false;

            pnlTop.Controls.Add(pnlHud);
            pnlTop.Controls.Add(lblTitle);

            picBackground.Dock        = DockStyle.Fill;
            picBackground.SizeMode    = PictureBoxSizeMode.Zoom;
            picBackground.BackColor   = Color.FromArgb(40, 40, 40);

            rtbText.Dock        = DockStyle.Bottom;
            rtbText.Height      = 160;
            rtbText.BackColor   = Color.FromArgb(20, 20, 20);
            rtbText.ForeColor   = Color.WhiteSmoke;
            rtbText.Font        = new Font("Segoe UI", 11);
            rtbText.ReadOnly    = true;
            rtbText.BorderStyle = BorderStyle.None;
            rtbText.Padding     = new Padding(10);
            rtbText.ScrollBars  = RichTextBoxScrollBars.Vertical;

            lblBlockId.AutoSize  = true;
            lblBlockId.BackColor = Color.FromArgb(0, 0, 0, 150);
            lblBlockId.ForeColor = Color.Gray;
            lblBlockId.Font      = new Font("Consolas", 8);
            lblBlockId.Location  = new Point(5, 5);

            var pnlCenter       = new Panel();
            pnlCenter.Dock      = DockStyle.Fill;
            pnlCenter.Controls.Add(lblBlockId);
            pnlCenter.Controls.Add(rtbText);
            pnlCenter.Controls.Add(picBackground);

            pnlDecisions.Dock         = DockStyle.Bottom;
            pnlDecisions.Height       = 130;
            pnlDecisions.BackColor    = Color.FromArgb(15, 15, 15);
            pnlDecisions.FlowDirection= FlowDirection.LeftToRight;
            pnlDecisions.WrapContents = true;
            pnlDecisions.Padding      = new Padding(10, 8, 10, 8);
            pnlDecisions.AutoScroll   = true;

            Controls.Add(pnlCenter);
            Controls.Add(pnlDecisions);
            Controls.Add(pnlTop);
            Controls.Add(menuStrip);
            MainMenuStrip = menuStrip;
        }

        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(20, 20, 20);
            menuStrip.ForeColor = Color.WhiteSmoke;
            menuStrip.Renderer  = new DarkMenuRenderer();

            var mnuFile = new ToolStripMenuItem("Fișier");
            mnuFile.DropDownItems.Add("Deschide poveste...",  null, OnOpenStory);
            mnuFile.DropDownItems.Add("Restart",              null, OnRestart);
            mnuFile.DropDownItems.Add(new ToolStripSeparator());
            mnuFile.DropDownItems.Add("Salvează starea...",   null, OnSaveState);
            mnuFile.DropDownItems.Add("Încarcă starea...",    null, OnLoadState);
            mnuFile.DropDownItems.Add(new ToolStripSeparator());
            mnuFile.DropDownItems.Add("Ieșire",               null, (s, e) => Close());

            menuStrip.Items.Add(mnuFile);
        }

        private void ShowWelcome()
        {
            rtbText.Text     = "Bun venit!\n\nDeschide o poveste din meniu → Fișier → Deschide poveste...";
            pnlDecisions.Controls.Clear();
            pnlHud.Controls.Clear();
            picBackground.Image = null;
            lblBlockId.Text  = string.Empty;
        }

        private void RefreshView()
        {
            if (_engine is null) return;

            var block = _engine.CurrentBlock;

            lblTitle.Text   = _engine.State.CurrentBlockId; 
            lblBlockId.Text = block.Id;

            rtbText.Text = block.Text;

            picBackground.Image = LoadBlockImage(block.BackgroundImage);

            RefreshHud();

            RefreshDecisions();
        }

        private void RefreshHud() => RefreshHudFull();

        private void RefreshDecisions()
        {
            if (_engine is null) return;
            pnlDecisions.Controls.Clear();

            if (_engine.IsGameOver)
            {
                var lblEnd = new Label
                {
                    Text      = "[ Sfârşit ]",
                    ForeColor = Color.Gold,
                    Font      = new Font("Segoe UI", 13, FontStyle.Bold),
                    AutoSize  = true,
                    Margin    = new Padding(10)
                };
                pnlDecisions.Controls.Add(lblEnd);
                return;
            }

            var decisions = _engine.GetAvailableDecisions();
            foreach (var dec in decisions)
            {
                var btn = new Button
                {
                    Text      = dec.Text,
                    AutoSize  = false,
                    Width     = 240,
                    Height    = 50,
                    Margin    = new Padding(6),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.FromArgb(50, 50, 70),
                    ForeColor = Color.WhiteSmoke,
                    Font      = new Font("Segoe UI", 10),
                    Tag       = dec
                };
                btn.FlatAppearance.BorderColor = Color.FromArgb(100, 100, 150);
                btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(70, 70, 110);
                btn.Click += OnDecisionClick;

                if (dec.Icon is not null)
                {
                    var img = LoadRelativeImage(dec.Icon);
                    if (img is not null)
                    {
                        btn.Image     = img;
                        btn.ImageAlign= ContentAlignment.MiddleLeft;
                        btn.TextAlign = ContentAlignment.MiddleRight;
                        btn.TextImageRelation = TextImageRelation.ImageBeforeText;
                    }
                }

                pnlDecisions.Controls.Add(btn);
            }
        }

        private Image? LoadBlockImage(string? relativePath)
        {
            if (relativePath is null || _currentZip is null) return null;
            if (_imageCache.TryGetValue(relativePath, out var cached)) return cached;

            byte[]? data = _repo.LoadImage(_currentZip, relativePath);
            if (data is null) return null;

            var img = Image.FromStream(new MemoryStream(data));
            _imageCache[relativePath] = img;
            return img;
        }

        private Image? LoadRelativeImage(string? relativePath) =>
            LoadBlockImage(relativePath);

        private void OnDecisionClick(object? sender, EventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not DecisionDefinition dec) return;
            if (_engine is null) return;

            try
            {
                _engine.ApplyDecision(dec);
                RefreshView();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la aplicarea deciziei:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnOpenStory(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog
            {
                Title  = "Deschide poveste",
                Filter = "Povești (*.zip)|*.zip|Toate fișierele|*.*"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                _currentZip  = dlg.FileName;
                _imageCache.Clear();

                var story = _repo.LoadFromZip(_currentZip);

                var errors = StoryValidator.Validate(story);
                if (errors.Count > 0)
                {
                    MessageBox.Show("Avertismente la încărcare:\n• " + string.Join("\n• ", errors),
                        "Validare", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                _engine = new GameEngineExtended(story);
                lblTitle.Text = story.Title;
                Text = $"Story Player — {story.Title}";
                RefreshView();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Nu s-a putut deschide povestea:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnRestart(object? sender, EventArgs e)
        {
            if (_engine is null) return;
            _engine.Restart();
            RefreshView();
        }

        private void OnSaveState(object? sender, EventArgs e)
        {
            if (_engine is null) { MessageBox.Show("Nicio poveste deschisă."); return; }
            using var dlg = new SaveFileDialog
            {
                Title  = "Salvează starea",
                Filter = "Stare joc (*.json)|*.json"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            _repo.SaveGameState(_engine.State, dlg.FileName);
            MessageBox.Show("Starea a fost salvată.", "Salvat", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OnLoadState(object? sender, EventArgs e)
        {
            if (_engine is null) { MessageBox.Show("Nicio poveste deschisă."); return; }
            using var dlg = new OpenFileDialog
            {
                Title  = "Încarcă starea",
                Filter = "Stare joc (*.json)|*.json"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            var state = _repo.LoadGameState(dlg.FileName);
            _engine.LoadState(state);
            RefreshView();
        }
    }

    internal class DarkMenuRenderer : ToolStripProfessionalRenderer
    {
        public DarkMenuRenderer() : base(new DarkColorTable()) { }
    }

    internal class DarkColorTable : ProfessionalColorTable
    {
        public override Color MenuItemSelected       => Color.FromArgb(60, 60, 80);
        public override Color MenuItemBorder         => Color.FromArgb(100, 100, 140);
        public override Color MenuBorder             => Color.FromArgb(60, 60, 80);
        public override Color ToolStripDropDownBackground => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientBegin    => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientMiddle   => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientEnd      => Color.FromArgb(25, 25, 25);
    }
}
