using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Story.Player
{
    partial class MainForm
    {

        private void RefreshHudFull()
        {
            pnlHud.Controls.Clear();
            if (_engine is not GameEngineExtended ext) return;

            var props = ext.Story.Properties
                .Where(p => p.VisibleInHud)
                .OrderBy(p => p.HudOrder);

            foreach (var prop in props)
            {
                if (!ext.State.Properties.TryGetValue(prop.Key, out double val)) continue;

                var pnl = new Panel
                {
                    Width     = 90,
                    Height    = 44,
                    Margin    = new Padding(4, 0, 4, 0),
                    BackColor = Color.FromArgb(35, 35, 55)
                };

                var lblName = new Label
                {
                    Text      = prop.HudLabel,
                    ForeColor = Color.Silver,
                    Font      = new Font("Segoe UI", 7),
                    AutoSize  = false,
                    Width     = 90,
                    Height    = 16,
                    Location  = new Point(0, 2),
                    TextAlign = System.Drawing.ContentAlignment.MiddleCenter
                };

                var lblVal = new Label
                {
                    Text      = FormatHudValue(val, prop.Min, prop.Max),
                    ForeColor = GetHudColor(val, prop.Min, prop.Max),
                    Font      = new Font("Segoe UI", 11, FontStyle.Bold),
                    AutoSize  = false,
                    Width     = 90,
                    Height    = 26,
                    Location  = new Point(0, 18),
                    TextAlign = System.Drawing.ContentAlignment.MiddleCenter
                };

                pnl.Controls.Add(lblName);
                pnl.Controls.Add(lblVal);
                pnlHud.Controls.Add(pnl);
            }
        }

        private static string FormatHudValue(double val, double min, double max)
        {
            
            if (min == 0 && max == 1)
                return val >= 1 ? "✓" : "✗";

            return ((int)val).ToString();
        }

        private static Color GetHudColor(double val, double min, double max)
        {
            double pct = (max - min) > 0 ? (val - min) / (max - min) : 0;

            if (pct <= 0.2) return Color.OrangeRed;
            if (pct <= 0.5) return Color.Gold;
            return Color.LightGreen;
        }
    }
}
