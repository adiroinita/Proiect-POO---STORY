using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Story.Engine;
using Story.Model;
using Story.Persistence;

namespace Story.Editor
{
    public partial class EditorForm : Form
    {
        private StoryDefinition _story   = NewEmptyStory();
        private StoryRepository _repo    = new();
        private string          _zipPath = string.Empty;
        private bool            _isDirty = false;

        private MetadataPanel?  pnlMetadata;
        private PropertyPanel?  pnlProperty;
        private BlockPanel?     pnlBlock;

        public EditorForm()
        {
            InitializeComponent();
            menuStrip.Renderer = new DarkMenuRenderer();
            LoadStoryIntoTree();
        }

        private void LoadStoryIntoTree()
        {
            treeView.BeginUpdate();
            treeView.Nodes.Clear();

            var root = new TreeNode($"📖 {_story.Title}") { Tag = _story, Name = "root" };

            var nodeMetadata = new TreeNode("⚙ Metadate") { Tag = "metadata", Name = "metadata" };
            root.Nodes.Add(nodeMetadata);

            var nodeProps = new TreeNode("📊 Proprietăți") { Tag = "properties", Name = "properties" };
            foreach (var prop in _story.Properties)
                nodeProps.Nodes.Add(MakePropNode(prop));
            root.Nodes.Add(nodeProps);

            var nodeBlocks = new TreeNode("🧱 Blocuri") { Tag = "blocks", Name = "blocks" };
            foreach (var block in _story.Blocks)
                nodeBlocks.Nodes.Add(MakeBlockNode(block));
            root.Nodes.Add(nodeBlocks);

            treeView.Nodes.Add(root);
            root.Expand();
            nodeBlocks.Expand();
            treeView.EndUpdate();
        }

        private TreeNode MakePropNode(StatePropertyDefinition prop) =>
            new TreeNode($"  {prop.Key}") { Tag = prop, Name = "prop_" + prop.Key };

        private TreeNode MakeBlockNode(StoryBlock block)
        {
            string icon = block.IsFinal ? "🏁" : "▶";
            return new TreeNode($"  {icon} {block.Id}") { Tag = block, Name = "block_" + block.Id };
        }

        private void OnTreeSelect(object? sender, TreeViewEventArgs e)
        {
            if (e.Node?.Tag is null) return;
            SwapEditPanel(e.Node.Tag);
        }

        private void SwapEditPanel(object tag)
        {
            pnlEdit.Controls.Clear();

            Control? panel = tag switch
            {
                StoryDefinition s               => GetOrCreate(ref pnlMetadata,  () => new MetadataPanel(s, OnModelChanged)),
                string t when t == "metadata"   => GetOrCreate(ref pnlMetadata,  () => new MetadataPanel(_story, OnModelChanged)),
                StatePropertyDefinition p       => (pnlProperty = new PropertyPanel(p, _story, OnModelChanged)),
                StoryBlock b                    => (pnlBlock    = new BlockPanel(b, _story, _zipPath, OnModelChanged)),
                _                               => null
            };

            if (panel is null) return;
            panel.Dock = DockStyle.Fill;
            pnlEdit.Controls.Add(panel);
        }

        private T GetOrCreate<T>(ref T? field, Func<T> factory) where T : class
        {
            field ??= factory();
            return field;
        }

        private void OnModelChanged()
        {
            _isDirty = true;
            LoadStoryIntoTree();
            UpdateTitle();
        }

        private void UpdateTitle()
        {
            string dirty = _isDirty ? " *" : string.Empty;
            string file  = string.IsNullOrEmpty(_zipPath) ? "Nesalvat" : Path.GetFileName(_zipPath);
            Text = $"Story Editor — {_story.Title} [{file}]{dirty}";
        }

        private void SetStatus(string msg) => lblStatus.Text = "  " + msg;

        private void OnNewStory(object? sender, EventArgs e)
        {
            if (!ConfirmDiscard()) return;
            _story   = NewEmptyStory();
            _zipPath = string.Empty;
            _isDirty = false;
            LoadStoryIntoTree();
            UpdateTitle();
        }

        private void OnOpenStory(object? sender, EventArgs e)
        {
            if (!ConfirmDiscard()) return;
            using var dlg = new OpenFileDialog { Filter = "Povești (*.zip)|*.zip" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                _story   = _repo.LoadFromZip(dlg.FileName);
                _zipPath = dlg.FileName;
                _isDirty = false;
                LoadStoryIntoTree();
                UpdateTitle();
                SetStatus($"Deschis: {_zipPath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la deschidere:\n{ex.Message}", "Eroare",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnSave(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_zipPath)) { OnSaveAs(sender, e); return; }
            SaveToZip(_zipPath);
        }

        private void OnSaveAs(object? sender, EventArgs e)
        {
            using var dlg = new SaveFileDialog { Filter = "Povești (*.zip)|*.zip", FileName = _story.Title + ".zip" };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            SaveToZip(dlg.FileName);
        }

        private void SaveToZip(string path)
        {
            var errors = StoryValidator.Validate(_story);
            if (errors.Count > 0)
            {
                var result = MessageBox.Show(
                    "Sunt erori de validare:\n• " + string.Join("\n• ", errors) +
                    "\n\nSalvezi totuși?",
                    "Validare", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result != DialogResult.Yes) return;
            }

            try
            {
                _repo.SaveToZip(_story, path, imageFiles: null);
                _zipPath = path;
                _isDirty = false;
                UpdateTitle();
                SetStatus($"Salvat: {path}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la salvare:\n{ex.Message}", "Eroare",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnAddBlock(object? sender, EventArgs e)
        {
            string id = $"block.{_story.Blocks.Count + 1}";
            _story.Blocks.Add(new StoryBlock { Id = id, Text = "Text nou..." });
            OnModelChanged();
        }

        private void OnDeleteSelected(object? sender, EventArgs e)
        {
            var node = treeView.SelectedNode;
            if (node?.Tag is StoryBlock block)
            {
                if (MessageBox.Show($"Ștergi blocul '{block.Id}'?", "Confirmare",
                        MessageBoxButtons.YesNo) != DialogResult.Yes) return;
                _story.Blocks.Remove(block);
                OnModelChanged();
            }
            else if (node?.Tag is StatePropertyDefinition prop)
            {
                _story.Properties.Remove(prop);
                OnModelChanged();
            }
        }

        private void OnValidate(object? sender, EventArgs e)
        {
            var errors = StoryValidator.Validate(_story);
            if (errors.Count == 0)
                MessageBox.Show("✓ Povestea este validă!", "Validare",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Erori:\n• " + string.Join("\n• ", errors), "Validare",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private bool ConfirmDiscard()
        {
            if (!_isDirty) return true;
            var r = MessageBox.Show("Ai modificări nesalvate. Continui?", "Confirmare",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            return r == DialogResult.Yes;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_isDirty && !ConfirmDiscard()) e.Cancel = true;
            base.OnFormClosing(e);
        }

        private static StoryDefinition NewEmptyStory() => new()
        {
            Title      = "Poveste nouă",
            StartBlock = "intro.start",
            Blocks     = new() { new StoryBlock { Id = "intro.start", Text = "Povestea începe..." } },
            Properties = new()
        };
    }
}
