namespace Story.Editor
{
    partial class DecisionDialog
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblText       = new System.Windows.Forms.Label();
            this.txtText       = new System.Windows.Forms.TextBox();
            this.lblTarget     = new System.Windows.Forms.Label();
            this.txtTarget     = new System.Windows.Forms.TextBox();
            this.lblIcon       = new System.Windows.Forms.Label();
            this.txtIcon       = new System.Windows.Forms.TextBox();
            this.lblEffects    = new System.Windows.Forms.Label();
            this.gridEffects   = new System.Windows.Forms.DataGridView();
            this.colType       = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colProp       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colValue      = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCondition  = new System.Windows.Forms.Label();
            this.txtCondition  = new System.Windows.Forms.RichTextBox();
            this.btnOk         = new System.Windows.Forms.Button();
            this.btnCancel     = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridEffects)).BeginInit();
            this.SuspendLayout();

            var dark   = System.Drawing.Color.FromArgb(45, 45, 45);
            var dark2  = System.Drawing.Color.FromArgb(35, 35, 35);
            var dark3  = System.Drawing.Color.FromArgb(40, 40, 40);
            var hdr    = System.Drawing.Color.FromArgb(25, 25, 25);
            var white  = System.Drawing.Color.WhiteSmoke;
            var silver = System.Drawing.Color.Silver;
            var gold   = System.Drawing.Color.Gold;
            var btn    = System.Drawing.Color.FromArgb(50, 50, 80);
            var btnBdr = System.Drawing.Color.FromArgb(80, 80, 120);
            var segoe9  = new System.Drawing.Font("Segoe UI", 9F);
            var segoe10 = new System.Drawing.Font("Segoe UI", 10F);
            var segoe13b= new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);

            // lblText / txtText
            this.lblText.AutoSize=true; this.lblText.Font=segoe9; this.lblText.ForeColor=silver;
            this.lblText.Location=new System.Drawing.Point(10,12); this.lblText.Text="Text decizie:";
            this.txtText.BackColor=dark; this.txtText.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtText.Font=segoe10; this.txtText.ForeColor=white;
            this.txtText.Location=new System.Drawing.Point(130,9); this.txtText.Size=new System.Drawing.Size(430,25);

            // lblTarget / txtTarget
            this.lblTarget.AutoSize=true; this.lblTarget.Font=segoe9; this.lblTarget.ForeColor=silver;
            this.lblTarget.Location=new System.Drawing.Point(10,47); this.lblTarget.Text="Bloc țintă:";
            this.txtTarget.BackColor=dark; this.txtTarget.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTarget.Font=segoe10; this.txtTarget.ForeColor=white;
            this.txtTarget.Location=new System.Drawing.Point(130,44); this.txtTarget.Size=new System.Drawing.Size(280,25);

            // lblIcon / txtIcon
            this.lblIcon.AutoSize=true; this.lblIcon.Font=segoe9; this.lblIcon.ForeColor=silver;
            this.lblIcon.Location=new System.Drawing.Point(10,82); this.lblIcon.Text="Iconiță:";
            this.txtIcon.BackColor=dark; this.txtIcon.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.Font=segoe10; this.txtIcon.ForeColor=white;
            this.txtIcon.Location=new System.Drawing.Point(130,79); this.txtIcon.Size=new System.Drawing.Size(280,25);

            // lblEffects
            this.lblEffects.AutoSize=true; this.lblEffects.Font=segoe13b;
            this.lblEffects.ForeColor=gold; this.lblEffects.Location=new System.Drawing.Point(10,118);
            this.lblEffects.Text="Efecte";

            // gridEffects
            this.gridEffects.AllowUserToAddRows=true;
            this.gridEffects.BackgroundColor=dark2;
            this.gridEffects.BorderStyle=System.Windows.Forms.BorderStyle.None;
            this.gridEffects.ColumnHeadersDefaultCellStyle.BackColor=hdr;
            this.gridEffects.ColumnHeadersDefaultCellStyle.ForeColor=gold;
            this.gridEffects.DefaultCellStyle.BackColor=dark3;
            this.gridEffects.DefaultCellStyle.ForeColor=white;
            this.gridEffects.Location=new System.Drawing.Point(10,148);
            this.gridEffects.Size=new System.Drawing.Size(550,130);
            this.gridEffects.RowHeadersVisible=false;

            this.colType.HeaderText="Tip"; this.colType.Name="type"; this.colType.Width=60;
            this.colType.Items.AddRange("ADD","SET");
            this.colProp.HeaderText="Proprietate"; this.colProp.Name="prop"; this.colProp.Width=200;
            this.colValue.HeaderText="Valoare"; this.colValue.Name="value"; this.colValue.Width=80;
            this.gridEffects.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
                { this.colType, this.colProp, this.colValue });

            // lblCondition / txtCondition
            this.lblCondition.AutoSize=true; this.lblCondition.Font=segoe13b;
            this.lblCondition.ForeColor=gold; this.lblCondition.Location=new System.Drawing.Point(10,292);
            this.lblCondition.Text="Condiție (JSON)";
            this.txtCondition.BackColor=dark; this.txtCondition.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCondition.Font=new System.Drawing.Font("Consolas",9F);
            this.txtCondition.ForeColor=System.Drawing.Color.LightGreen;
            this.txtCondition.Location=new System.Drawing.Point(10,322); this.txtCondition.Size=new System.Drawing.Size(550,80);

            // btnOk / btnCancel
            this.btnOk.BackColor=btn; this.btnOk.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.Font=segoe9; this.btnOk.ForeColor=white;
            this.btnOk.Location=new System.Drawing.Point(10,415); this.btnOk.Size=new System.Drawing.Size(70,26);
            this.btnOk.Text="OK"; this.btnOk.FlatAppearance.BorderColor=btnBdr;
            this.btnOk.Click+=new System.EventHandler(this.btnOk_Click);

            this.btnCancel.BackColor=btn; this.btnCancel.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font=segoe9; this.btnCancel.ForeColor=white;
            this.btnCancel.Location=new System.Drawing.Point(90,415); this.btnCancel.Size=new System.Drawing.Size(80,26);
            this.btnCancel.Text="Anulează"; this.btnCancel.FlatAppearance.BorderColor=btnBdr;
            this.btnCancel.Click+=new System.EventHandler(this.btnCancel_Click);

            // DecisionDialog
            this.AutoScaleDimensions=new System.Drawing.SizeF(7F,15F);
            this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor=System.Drawing.Color.FromArgb(30,30,30);
            this.ClientSize=new System.Drawing.Size(580,455);
            this.Controls.Add(this.lblText); this.Controls.Add(this.txtText);
            this.Controls.Add(this.lblTarget); this.Controls.Add(this.txtTarget);
            this.Controls.Add(this.lblIcon); this.Controls.Add(this.txtIcon);
            this.Controls.Add(this.lblEffects); this.Controls.Add(this.gridEffects);
            this.Controls.Add(this.lblCondition); this.Controls.Add(this.txtCondition);
            this.Controls.Add(this.btnOk); this.Controls.Add(this.btnCancel);
            this.ForeColor=System.Drawing.Color.WhiteSmoke;
            this.MinimumSize=new System.Drawing.Size(500,450);
            this.Name="DecisionDialog";
            this.StartPosition=System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text="Editare decizie";
            ((System.ComponentModel.ISupportInitialize)(this.gridEffects)).EndInit();
            this.ResumeLayout(false); this.PerformLayout();
        }

        private System.Windows.Forms.Label                      lblText;
        private System.Windows.Forms.TextBox                    txtText;
        private System.Windows.Forms.Label                      lblTarget;
        private System.Windows.Forms.TextBox                    txtTarget;
        private System.Windows.Forms.Label                      lblIcon;
        private System.Windows.Forms.TextBox                    txtIcon;
        private System.Windows.Forms.Label                      lblEffects;
        private System.Windows.Forms.DataGridView               gridEffects;
        private System.Windows.Forms.DataGridViewComboBoxColumn colType;
        private System.Windows.Forms.DataGridViewTextBoxColumn  colProp;
        private System.Windows.Forms.DataGridViewTextBoxColumn  colValue;
        private System.Windows.Forms.Label                      lblCondition;
        private System.Windows.Forms.RichTextBox                txtCondition;
        private System.Windows.Forms.Button                     btnOk;
        private System.Windows.Forms.Button                     btnCancel;
    }
}
