using System;
using System.Drawing;
using System.Windows.Forms;
using Story.Model;
using Story.Model.Effects;

namespace Story.Editor
{
    internal partial class DecisionDialog : Form
    {
        private readonly DecisionDefinition _dec;
        private readonly StoryDefinition    _story;

        public DecisionDialog(DecisionDefinition dec, StoryDefinition story)
        {
            _dec   = dec;
            _story = story;
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            txtText.Text   = _dec.Text;
            txtTarget.Text = _dec.TargetBlock;
            txtIcon.Text   = _dec.Icon ?? "";

            foreach (var eff in _dec.Effects)
                gridEffects.Rows.Add(eff.Type.ToString(), eff.Property, eff.Value);

            if (_dec.Condition != null)
                txtCondition.Text = System.Text.Json.JsonSerializer.Serialize(
                    _dec.Condition,
                    new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            _dec.Text        = txtText.Text;
            _dec.TargetBlock = txtTarget.Text;
            _dec.Icon        = string.IsNullOrWhiteSpace(txtIcon.Text) ? null : txtIcon.Text;

            _dec.Effects.Clear();
            foreach (DataGridViewRow row in gridEffects.Rows)
            {
                if (row.IsNewRow) continue;
                if (row.Cells["prop"].Value is not string prop || string.IsNullOrWhiteSpace(prop)) continue;
                var type = row.Cells["type"].Value?.ToString() == "SET" ? EffectType.SET : EffectType.ADD;
                double.TryParse(row.Cells["value"].Value?.ToString(), out double val);
                _dec.Effects.Add(new EffectDefinition { Type = type, Property = prop, Value = val });
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
