namespace Story.Editor
{
    partial class MetadataPanel
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle       = new System.Windows.Forms.Label();
            this.lblTitleField  = new System.Windows.Forms.Label();
            this.txtTitle       = new System.Windows.Forms.TextBox();
            this.lblStart       = new System.Windows.Forms.Label();
            this.txtStart       = new System.Windows.Forms.TextBox();
            this.btnAddProperty = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblTitle (heading)
            this.lblTitle.AutoSize  = true;
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.Gold;
            this.lblTitle.Location  = new System.Drawing.Point(0, 10);
            this.lblTitle.Name      = "lblTitle";
            this.lblTitle.Text      = "Metadate poveste";

            // lblTitleField
            this.lblTitleField.AutoSize  = true;
            this.lblTitleField.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTitleField.ForeColor = System.Drawing.Color.Silver;
            this.lblTitleField.Location  = new System.Drawing.Point(0, 55);
            this.lblTitleField.Name      = "lblTitleField";
            this.lblTitleField.Text      = "Titlu:";

            // txtTitle
            this.txtTitle.BackColor   = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTitle.Font        = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTitle.ForeColor   = System.Drawing.Color.WhiteSmoke;
            this.txtTitle.Location    = new System.Drawing.Point(80, 52);
            this.txtTitle.Name        = "txtTitle";
            this.txtTitle.Size        = new System.Drawing.Size(300, 25);
            this.txtTitle.TabIndex    = 0;
            this.txtTitle.TextChanged += new System.EventHandler(this.txtTitle_TextChanged);

            // lblStart
            this.lblStart.AutoSize  = true;
            this.lblStart.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.lblStart.ForeColor = System.Drawing.Color.Silver;
            this.lblStart.Location  = new System.Drawing.Point(0, 90);
            this.lblStart.Name      = "lblStart";
            this.lblStart.Text      = "Start bloc:";

            // txtStart
            this.txtStart.BackColor   = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStart.Font        = new System.Drawing.Font("Segoe UI", 10F);
            this.txtStart.ForeColor   = System.Drawing.Color.WhiteSmoke;
            this.txtStart.Location    = new System.Drawing.Point(100, 87);
            this.txtStart.Name        = "txtStart";
            this.txtStart.Size        = new System.Drawing.Size(250, 25);
            this.txtStart.TabIndex    = 1;
            this.txtStart.TextChanged += new System.EventHandler(this.txtStart_TextChanged);

            // btnAddProperty
            this.btnAddProperty.BackColor = System.Drawing.Color.FromArgb(50, 50, 80);
            this.btnAddProperty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProperty.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAddProperty.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddProperty.Location  = new System.Drawing.Point(0, 130);
            this.btnAddProperty.Name      = "btnAddProperty";
            this.btnAddProperty.Size      = new System.Drawing.Size(120, 28);
            this.btnAddProperty.TabIndex  = 2;
            this.btnAddProperty.Text      = "+ Proprietate";
            this.btnAddProperty.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 80, 120);
            this.btnAddProperty.Click += new System.EventHandler(this.btnAddProperty_Click);

            // MetadataPanel
            this.AutoScroll = true;
            this.BackColor  = System.Drawing.Color.FromArgb(30, 30, 30);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblTitleField);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.txtStart);
            this.Controls.Add(this.btnAddProperty);
            this.Name = "MetadataPanel";
            this.Size = new System.Drawing.Size(600, 300);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label   lblTitle;
        private System.Windows.Forms.Label   lblTitleField;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label   lblStart;
        private System.Windows.Forms.TextBox txtStart;
        private System.Windows.Forms.Button  btnAddProperty;
    }
}
