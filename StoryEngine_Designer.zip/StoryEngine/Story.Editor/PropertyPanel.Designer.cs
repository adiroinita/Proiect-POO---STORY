namespace Story.Editor
{
    partial class PropertyPanel
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeading  = new System.Windows.Forms.Label();
            this.lblKey      = new System.Windows.Forms.Label();
            this.txtKey      = new System.Windows.Forms.TextBox();
            this.lblHud      = new System.Windows.Forms.Label();
            this.txtHud      = new System.Windows.Forms.TextBox();
            this.lblMin      = new System.Windows.Forms.Label();
            this.numMin      = new System.Windows.Forms.NumericUpDown();
            this.lblMax      = new System.Windows.Forms.Label();
            this.numMax      = new System.Windows.Forms.NumericUpDown();
            this.lblInit     = new System.Windows.Forms.Label();
            this.numInit     = new System.Windows.Forms.NumericUpDown();
            this.chkVisible  = new System.Windows.Forms.CheckBox();
            this.lblOrder    = new System.Windows.Forms.Label();
            this.numOrder    = new System.Windows.Forms.NumericUpDown();
            this.lblOnMin    = new System.Windows.Forms.Label();
            this.txtOnMin    = new System.Windows.Forms.TextBox();
            this.lblOnMax    = new System.Windows.Forms.Label();
            this.txtOnMax    = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOrder)).BeginInit();
            this.SuspendLayout();

            var dark  = System.Drawing.Color.FromArgb(45, 45, 45);
            var white = System.Drawing.Color.WhiteSmoke;
            var silver= System.Drawing.Color.Silver;
            var segoe9  = new System.Drawing.Font("Segoe UI", 9F);
            var segoe10 = new System.Drawing.Font("Segoe UI", 10F);

            // lblHeading
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font     = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblHeading.ForeColor= System.Drawing.Color.Gold;
            this.lblHeading.Location = new System.Drawing.Point(0, 10);
            this.lblHeading.Text     = "Proprietate";

            // row 1 - Key
            this.lblKey.AutoSize=true; this.lblKey.Font=segoe9; this.lblKey.ForeColor=silver;
            this.lblKey.Location=new System.Drawing.Point(0,55); this.lblKey.Text="Cheie:";
            this.txtKey.BackColor=dark; this.txtKey.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKey.Font=segoe10; this.txtKey.ForeColor=white;
            this.txtKey.Location=new System.Drawing.Point(80,52); this.txtKey.Size=new System.Drawing.Size(220,25);
            this.txtKey.TextChanged+=new System.EventHandler(this.txtKey_TextChanged);

            // row 2 - HudLabel
            this.lblHud.AutoSize=true; this.lblHud.Font=segoe9; this.lblHud.ForeColor=silver;
            this.lblHud.Location=new System.Drawing.Point(0,88); this.lblHud.Text="Etichetă HUD:";
            this.txtHud.BackColor=dark; this.txtHud.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHud.Font=segoe10; this.txtHud.ForeColor=white;
            this.txtHud.Location=new System.Drawing.Point(120,85); this.txtHud.Size=new System.Drawing.Size(180,25);
            this.txtHud.TextChanged+=new System.EventHandler(this.txtHud_TextChanged);

            // row 3 - Min / Max / Init
            this.lblMin.AutoSize=true; this.lblMin.Font=segoe9; this.lblMin.ForeColor=silver;
            this.lblMin.Location=new System.Drawing.Point(0,121); this.lblMin.Text="Min:";
            this.numMin.BackColor=dark; this.numMin.ForeColor=white; this.numMin.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.numMin.Font=segoe10; this.numMin.Location=new System.Drawing.Point(40,118);
            this.numMin.Size=new System.Drawing.Size(80,25); this.numMin.Minimum=-99999; this.numMin.Maximum=99999;
            this.numMin.ValueChanged+=new System.EventHandler(this.numMin_ValueChanged);

            this.lblMax.AutoSize=true; this.lblMax.Font=segoe9; this.lblMax.ForeColor=silver;
            this.lblMax.Location=new System.Drawing.Point(135,121); this.lblMax.Text="Max:";
            this.numMax.BackColor=dark; this.numMax.ForeColor=white; this.numMax.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.numMax.Font=segoe10; this.numMax.Location=new System.Drawing.Point(175,118);
            this.numMax.Size=new System.Drawing.Size(80,25); this.numMax.Minimum=-99999; this.numMax.Maximum=99999;
            this.numMax.ValueChanged+=new System.EventHandler(this.numMax_ValueChanged);

            this.lblInit.AutoSize=true; this.lblInit.Font=segoe9; this.lblInit.ForeColor=silver;
            this.lblInit.Location=new System.Drawing.Point(270,121); this.lblInit.Text="Inițial:";
            this.numInit.BackColor=dark; this.numInit.ForeColor=white; this.numInit.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.numInit.Font=segoe10; this.numInit.Location=new System.Drawing.Point(325,118);
            this.numInit.Size=new System.Drawing.Size(80,25); this.numInit.Minimum=-99999; this.numInit.Maximum=99999;
            this.numInit.ValueChanged+=new System.EventHandler(this.numInit_ValueChanged);

            // row 4 - Visible / Order
            this.chkVisible.AutoSize=true; this.chkVisible.Font=segoe10; this.chkVisible.ForeColor=white;
            this.chkVisible.Location=new System.Drawing.Point(0,155); this.chkVisible.Text="Vizibil în HUD";
            this.chkVisible.CheckedChanged+=new System.EventHandler(this.chkVisible_CheckedChanged);

            this.lblOrder.AutoSize=true; this.lblOrder.Font=segoe9; this.lblOrder.ForeColor=silver;
            this.lblOrder.Location=new System.Drawing.Point(180,158); this.lblOrder.Text="Ordine HUD:";
            this.numOrder.BackColor=dark; this.numOrder.ForeColor=white; this.numOrder.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.numOrder.Font=segoe10; this.numOrder.Location=new System.Drawing.Point(275,155);
            this.numOrder.Size=new System.Drawing.Size(60,25); this.numOrder.Minimum=0; this.numOrder.Maximum=999;
            this.numOrder.ValueChanged+=new System.EventHandler(this.numOrder_ValueChanged);

            // row 5 - OnMinBlock
            this.lblOnMin.AutoSize=true; this.lblOnMin.Font=segoe9; this.lblOnMin.ForeColor=silver;
            this.lblOnMin.Location=new System.Drawing.Point(0,191); this.lblOnMin.Text="onMinBlock:";
            this.txtOnMin.BackColor=dark; this.txtOnMin.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOnMin.Font=segoe10; this.txtOnMin.ForeColor=white;
            this.txtOnMin.Location=new System.Drawing.Point(110,188); this.txtOnMin.Size=new System.Drawing.Size(200,25);
            this.txtOnMin.TextChanged+=new System.EventHandler(this.txtOnMin_TextChanged);

            // row 6 - OnMaxBlock
            this.lblOnMax.AutoSize=true; this.lblOnMax.Font=segoe9; this.lblOnMax.ForeColor=silver;
            this.lblOnMax.Location=new System.Drawing.Point(0,224); this.lblOnMax.Text="onMaxBlock:";
            this.txtOnMax.BackColor=dark; this.txtOnMax.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOnMax.Font=segoe10; this.txtOnMax.ForeColor=white;
            this.txtOnMax.Location=new System.Drawing.Point(110,221); this.txtOnMax.Size=new System.Drawing.Size(200,25);
            this.txtOnMax.TextChanged+=new System.EventHandler(this.txtOnMax_TextChanged);

            // PropertyPanel
            this.AutoScroll=true;
            this.BackColor=System.Drawing.Color.FromArgb(30,30,30);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.lblKey); this.Controls.Add(this.txtKey);
            this.Controls.Add(this.lblHud); this.Controls.Add(this.txtHud);
            this.Controls.Add(this.lblMin); this.Controls.Add(this.numMin);
            this.Controls.Add(this.lblMax); this.Controls.Add(this.numMax);
            this.Controls.Add(this.lblInit); this.Controls.Add(this.numInit);
            this.Controls.Add(this.chkVisible);
            this.Controls.Add(this.lblOrder); this.Controls.Add(this.numOrder);
            this.Controls.Add(this.lblOnMin); this.Controls.Add(this.txtOnMin);
            this.Controls.Add(this.lblOnMax); this.Controls.Add(this.txtOnMax);
            this.Name="PropertyPanel"; this.Size=new System.Drawing.Size(600,350);
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numInit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOrder)).EndInit();
            this.ResumeLayout(false); this.PerformLayout();
        }

        private System.Windows.Forms.Label            lblHeading;
        private System.Windows.Forms.Label            lblKey;
        private System.Windows.Forms.TextBox          txtKey;
        private System.Windows.Forms.Label            lblHud;
        private System.Windows.Forms.TextBox          txtHud;
        private System.Windows.Forms.Label            lblMin;
        private System.Windows.Forms.NumericUpDown    numMin;
        private System.Windows.Forms.Label            lblMax;
        private System.Windows.Forms.NumericUpDown    numMax;
        private System.Windows.Forms.Label            lblInit;
        private System.Windows.Forms.NumericUpDown    numInit;
        private System.Windows.Forms.CheckBox         chkVisible;
        private System.Windows.Forms.Label            lblOrder;
        private System.Windows.Forms.NumericUpDown    numOrder;
        private System.Windows.Forms.Label            lblOnMin;
        private System.Windows.Forms.TextBox          txtOnMin;
        private System.Windows.Forms.Label            lblOnMax;
        private System.Windows.Forms.TextBox          txtOnMax;
    }
}
