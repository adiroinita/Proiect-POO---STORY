namespace Story.Editor
{
    partial class BlockPanel
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeading      = new System.Windows.Forms.Label();
            this.lblId           = new System.Windows.Forms.Label();
            this.txtId           = new System.Windows.Forms.TextBox();
            this.chkFinal        = new System.Windows.Forms.CheckBox();
            this.lblText         = new System.Windows.Forms.Label();
            this.rtbText         = new System.Windows.Forms.RichTextBox();
            this.lblImage        = new System.Windows.Forms.Label();
            this.txtImage        = new System.Windows.Forms.TextBox();
            this.btnBrowse       = new System.Windows.Forms.Button();
            this.lblDecisions    = new System.Windows.Forms.Label();
            this.btnAddDecision  = new System.Windows.Forms.Button();
            this.btnEditDecision = new System.Windows.Forms.Button();
            this.btnDelDecision  = new System.Windows.Forms.Button();
            this.gridDecisions   = new System.Windows.Forms.DataGridView();
            this.colText         = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTarget       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCond         = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEffects      = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gridDecisions)).BeginInit();
            this.SuspendLayout();

            var dark   = System.Drawing.Color.FromArgb(45, 45, 45);
            var dark2  = System.Drawing.Color.FromArgb(35, 35, 35);
            var dark3  = System.Drawing.Color.FromArgb(40, 40, 40);
            var hdr    = System.Drawing.Color.FromArgb(25, 25, 25);
            var white  = System.Drawing.Color.WhiteSmoke;
            var silver = System.Drawing.Color.Silver;
            var gold   = System.Drawing.Color.Gold;
            var btn    = System.Drawing.Color.FromArgb(50, 50, 80);
            var btnBdr = System.Drawing.Color.FromArgb(80, 80, 120);
            var segoe9  = new System.Drawing.Font("Segoe UI", 9F);
            var segoe10 = new System.Drawing.Font("Segoe UI", 10F);
            var segoe13b = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);

            // lblHeading
            this.lblHeading.AutoSize=true; this.lblHeading.Font=segoe13b;
            this.lblHeading.ForeColor=gold; this.lblHeading.Location=new System.Drawing.Point(0,10);
            this.lblHeading.Text="Bloc";

            // lblId / txtId
            this.lblId.AutoSize=true; this.lblId.Font=segoe9; this.lblId.ForeColor=silver;
            this.lblId.Location=new System.Drawing.Point(0,55); this.lblId.Text="ID:";
            this.txtId.BackColor=dark; this.txtId.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtId.Font=segoe10; this.txtId.ForeColor=white;
            this.txtId.Location=new System.Drawing.Point(40,52); this.txtId.Size=new System.Drawing.Size(280,25);
            this.txtId.TextChanged+=new System.EventHandler(this.txtId_TextChanged);

            // chkFinal
            this.chkFinal.AutoSize=true; this.chkFinal.Font=segoe10; this.chkFinal.ForeColor=white;
            this.chkFinal.Location=new System.Drawing.Point(0,88); this.chkFinal.Text="Bloc final (sfârşit poveste)";
            this.chkFinal.CheckedChanged+=new System.EventHandler(this.chkFinal_CheckedChanged);

            // lblText
            this.lblText.AutoSize=true; this.lblText.Font=segoe9; this.lblText.ForeColor=silver;
            this.lblText.Location=new System.Drawing.Point(0,120); this.lblText.Text="Text narativ:";

            // rtbText
            this.rtbText.BackColor=dark; this.rtbText.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtbText.Font=segoe10; this.rtbText.ForeColor=white;
            this.rtbText.Location=new System.Drawing.Point(0,140); this.rtbText.Size=new System.Drawing.Size(500,120);
            this.rtbText.TextChanged+=new System.EventHandler(this.rtbText_TextChanged);

            // lblImage / txtImage / btnBrowse
            this.lblImage.AutoSize=true; this.lblImage.Font=segoe9; this.lblImage.ForeColor=silver;
            this.lblImage.Location=new System.Drawing.Point(0,273); this.lblImage.Text="Imagine fundal:";
            this.txtImage.BackColor=dark; this.txtImage.BorderStyle=System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtImage.Font=segoe10; this.txtImage.ForeColor=white;
            this.txtImage.Location=new System.Drawing.Point(130,270); this.txtImage.Size=new System.Drawing.Size(250,25);
            this.txtImage.TextChanged+=new System.EventHandler(this.txtImage_TextChanged);
            this.btnBrowse.BackColor=btn; this.btnBrowse.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font=segoe9; this.btnBrowse.ForeColor=white;
            this.btnBrowse.Location=new System.Drawing.Point(390,269); this.btnBrowse.Size=new System.Drawing.Size(75,26);
            this.btnBrowse.Text="Browse..."; this.btnBrowse.FlatAppearance.BorderColor=btnBdr;
            this.btnBrowse.Click+=new System.EventHandler(this.btnBrowse_Click);

            // lblDecisions
            this.lblDecisions.AutoSize=true; this.lblDecisions.Font=segoe13b;
            this.lblDecisions.ForeColor=gold; this.lblDecisions.Location=new System.Drawing.Point(0,310);
            this.lblDecisions.Text="Decizii";

            // btnAddDecision
            this.btnAddDecision.BackColor=btn; this.btnAddDecision.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnAddDecision.Font=segoe9; this.btnAddDecision.ForeColor=white;
            this.btnAddDecision.Location=new System.Drawing.Point(0,345); this.btnAddDecision.Size=new System.Drawing.Size(130,26);
            this.btnAddDecision.Text="+ Adaugă decizie"; this.btnAddDecision.FlatAppearance.BorderColor=btnBdr;
            this.btnAddDecision.Click+=new System.EventHandler(this.btnAddDecision_Click);

            // btnEditDecision
            this.btnEditDecision.BackColor=btn; this.btnEditDecision.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnEditDecision.Font=segoe9; this.btnEditDecision.ForeColor=white;
            this.btnEditDecision.Location=new System.Drawing.Point(140,345); this.btnEditDecision.Size=new System.Drawing.Size(90,26);
            this.btnEditDecision.Text="✏ Editează"; this.btnEditDecision.FlatAppearance.BorderColor=btnBdr;
            this.btnEditDecision.Click+=new System.EventHandler(this.btnEditDecision_Click);

            // btnDelDecision
            this.btnDelDecision.BackColor=btn; this.btnDelDecision.FlatStyle=System.Windows.Forms.FlatStyle.Flat;
            this.btnDelDecision.Font=segoe9; this.btnDelDecision.ForeColor=white;
            this.btnDelDecision.Location=new System.Drawing.Point(240,345); this.btnDelDecision.Size=new System.Drawing.Size(75,26);
            this.btnDelDecision.Text="✕ Șterge"; this.btnDelDecision.FlatAppearance.BorderColor=btnBdr;
            this.btnDelDecision.Click+=new System.EventHandler(this.btnDeleteDecision_Click);

            // gridDecisions
            this.gridDecisions.AllowUserToAddRows=false;
            this.gridDecisions.BackgroundColor=dark2;
            this.gridDecisions.BorderStyle=System.Windows.Forms.BorderStyle.None;
            this.gridDecisions.ColumnHeadersDefaultCellStyle.BackColor=hdr;
            this.gridDecisions.ColumnHeadersDefaultCellStyle.ForeColor=gold;
            this.gridDecisions.DefaultCellStyle.BackColor=dark3;
            this.gridDecisions.DefaultCellStyle.ForeColor=white;
            this.gridDecisions.GridColor=System.Drawing.Color.FromArgb(60,60,60);
            this.gridDecisions.Location=new System.Drawing.Point(0,380);
            this.gridDecisions.Size=new System.Drawing.Size(520,200);
            this.gridDecisions.ReadOnly=true;
            this.gridDecisions.RowHeadersVisible=false;
            this.gridDecisions.SelectionMode=System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDecisions.AutoSizeColumnsMode=System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.colText.HeaderText="Text decizie"; this.colText.Name="text";
            this.colTarget.HeaderText="Bloc țintă"; this.colTarget.Name="target";
            this.colCond.HeaderText="Condiție"; this.colCond.Name="cond";
            this.colEffects.HeaderText="Efecte"; this.colEffects.Name="effects";
            this.gridDecisions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
                { this.colText, this.colTarget, this.colCond, this.colEffects });

            // BlockPanel
            this.AutoScroll=true;
            this.BackColor=System.Drawing.Color.FromArgb(30,30,30);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.lblId); this.Controls.Add(this.txtId);
            this.Controls.Add(this.chkFinal);
            this.Controls.Add(this.lblText); this.Controls.Add(this.rtbText);
            this.Controls.Add(this.lblImage); this.Controls.Add(this.txtImage); this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.lblDecisions);
            this.Controls.Add(this.btnAddDecision); this.Controls.Add(this.btnEditDecision); this.Controls.Add(this.btnDelDecision);
            this.Controls.Add(this.gridDecisions);
            this.Name="BlockPanel"; this.Size=new System.Drawing.Size(600,600);
            ((System.ComponentModel.ISupportInitialize)(this.gridDecisions)).EndInit();
            this.ResumeLayout(false); this.PerformLayout();
        }

        private System.Windows.Forms.Label                          lblHeading;
        private System.Windows.Forms.Label                          lblId;
        private System.Windows.Forms.TextBox                        txtId;
        private System.Windows.Forms.CheckBox                       chkFinal;
        private System.Windows.Forms.Label                          lblText;
        private System.Windows.Forms.RichTextBox                    rtbText;
        private System.Windows.Forms.Label                          lblImage;
        private System.Windows.Forms.TextBox                        txtImage;
        private System.Windows.Forms.Button                         btnBrowse;
        private System.Windows.Forms.Label                          lblDecisions;
        private System.Windows.Forms.Button                         btnAddDecision;
        private System.Windows.Forms.Button                         btnEditDecision;
        private System.Windows.Forms.Button                         btnDelDecision;
        private System.Windows.Forms.DataGridView                   gridDecisions;
        private System.Windows.Forms.DataGridViewTextBoxColumn      colText;
        private System.Windows.Forms.DataGridViewTextBoxColumn      colTarget;
        private System.Windows.Forms.DataGridViewTextBoxColumn      colCond;
        private System.Windows.Forms.DataGridViewTextBoxColumn      colEffects;
    }
}
