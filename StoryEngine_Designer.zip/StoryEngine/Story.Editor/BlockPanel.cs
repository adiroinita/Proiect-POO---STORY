using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Story.Model;
using Story.Model.Effects;

namespace Story.Editor
{
    internal partial class BlockPanel : UserControl
    {
        private readonly StoryBlock      _block;
        private readonly StoryDefinition _story;
        private readonly string          _zipPath;
        private readonly Action          _onChange;

        public BlockPanel(StoryBlock block, StoryDefinition story, string zipPath, Action onChange)
        {
            _block    = block;
            _story    = story;
            _zipPath  = zipPath;
            _onChange = onChange;
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            txtId.Text              = _block.Id;
            chkFinal.Checked        = _block.IsFinal;
            rtbText.Text            = _block.Text;
            txtImage.Text           = _block.BackgroundImage ?? "";
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            gridDecisions.Rows.Clear();
            foreach (var dec in _block.Decisions)
            {
                string cond = dec.Condition is null ? "-" : "DA";
                string eff  = dec.Effects.Count == 0 ? "-" : $"{dec.Effects.Count} efect(e)";
                gridDecisions.Rows.Add(dec.Text, dec.TargetBlock, cond, eff);
            }
        }

        private void txtId_TextChanged(object s, EventArgs e)     { _block.Id = txtId.Text; _onChange(); }
        private void chkFinal_CheckedChanged(object s, EventArgs e) { _block.IsFinal = chkFinal.Checked; _onChange(); }
        private void rtbText_TextChanged(object s, EventArgs e)   { _block.Text = rtbText.Text; _onChange(); }
        private void txtImage_TextChanged(object s, EventArgs e)
        {
            _block.BackgroundImage = string.IsNullOrWhiteSpace(txtImage.Text) ? null : txtImage.Text;
            _onChange();
        }

        private void btnBrowse_Click(object s, EventArgs e)
        {
            using var dlg = new OpenFileDialog { Filter = "Imagini|*.jpg;*.jpeg;*.png;*.bmp" };
            if (dlg.ShowDialog() == DialogResult.OK)
                txtImage.Text = "images/" + Path.GetFileName(dlg.FileName);
        }

        private void btnAddDecision_Click(object s, EventArgs e)
        {
            var dec = new DecisionDefinition { Text = "Decizie nouă", TargetBlock = "intro.start" };
            _block.Decisions.Add(dec);
            using var dlg = new DecisionDialog(dec, _story);
            dlg.ShowDialog();
            _onChange();
            RefreshGrid();
        }

        private void btnEditDecision_Click(object s, EventArgs e)
        {
            if (gridDecisions.SelectedRows.Count == 0) return;
            int idx = gridDecisions.SelectedRows[0].Index;
            if (idx < 0 || idx >= _block.Decisions.Count) return;
            using var dlg = new DecisionDialog(_block.Decisions[idx], _story);
            dlg.ShowDialog();
            _onChange();
            RefreshGrid();
        }

        private void btnDeleteDecision_Click(object s, EventArgs e)
        {
            if (gridDecisions.SelectedRows.Count == 0) return;
            int idx = gridDecisions.SelectedRows[0].Index;
            if (idx < 0 || idx >= _block.Decisions.Count) return;
            _block.Decisions.RemoveAt(idx);
            _onChange();
            RefreshGrid();
        }
    }
}
