namespace Story.Editor
{
    partial class EditorForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip      = new System.Windows.Forms.MenuStrip();
            this.mnuFile        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNewStory    = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpen        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSep1        = new System.Windows.Forms.ToolStripSeparator();
            this.mnuSave        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSaveAs      = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSep2        = new System.Windows.Forms.ToolStripSeparator();
            this.mnuExit        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddBlock    = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete      = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStory       = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuValidate    = new System.Windows.Forms.ToolStripMenuItem();
            this.splitter       = new System.Windows.Forms.SplitContainer();
            this.treeView       = new System.Windows.Forms.TreeView();
            this.pnlEdit        = new System.Windows.Forms.Panel();
            this.lblStatus      = new System.Windows.Forms.Label();

            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitter)).BeginInit();
            this.splitter.Panel1.SuspendLayout();
            this.splitter.Panel2.SuspendLayout();
            this.splitter.SuspendLayout();
            this.SuspendLayout();

            // menuStrip
            this.menuStrip.BackColor = System.Drawing.Color.FromArgb(20, 20, 20);
            this.menuStrip.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuFile, this.mnuEdit, this.mnuStory });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1100, 24);
            this.menuStrip.TabIndex = 0;

            // mnuFile
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuNewStory, this.mnuOpen, this.mnuSep1,
                this.mnuSave, this.mnuSaveAs, this.mnuSep2, this.mnuExit });
            this.mnuFile.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Text = "Fișier";

            this.mnuNewStory.Name = "mnuNewStory"; this.mnuNewStory.Text = "Poveste nouă";
            this.mnuNewStory.Click += new System.EventHandler(this.OnNewStory);
            this.mnuOpen.Name    = "mnuOpen";    this.mnuOpen.Text    = "Deschide...";
            this.mnuOpen.Click  += new System.EventHandler(this.OnOpenStory);
            this.mnuSep1.Name   = "mnuSep1";
            this.mnuSave.Name   = "mnuSave";    this.mnuSave.Text    = "Salvează";
            this.mnuSave.Click += new System.EventHandler(this.OnSave);
            this.mnuSaveAs.Name = "mnuSaveAs";  this.mnuSaveAs.Text  = "Salvează ca...";
            this.mnuSaveAs.Click += new System.EventHandler(this.OnSaveAs);
            this.mnuSep2.Name   = "mnuSep2";
            this.mnuExit.Name   = "mnuExit";    this.mnuExit.Text    = "Ieșire";
            this.mnuExit.Click += (s, e) => Close();

            // mnuEdit
            this.mnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuAddBlock, this.mnuDelete });
            this.mnuEdit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.mnuEdit.Name = "mnuEdit"; this.mnuEdit.Text = "Editare";

            this.mnuAddBlock.Name = "mnuAddBlock"; this.mnuAddBlock.Text = "Adaugă bloc";
            this.mnuAddBlock.Click += new System.EventHandler(this.OnAddBlock);
            this.mnuDelete.Name   = "mnuDelete";   this.mnuDelete.Text   = "Șterge element selectat";
            this.mnuDelete.Click += new System.EventHandler(this.OnDeleteSelected);

            // mnuStory
            this.mnuStory.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuValidate });
            this.mnuStory.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.mnuStory.Name = "mnuStory"; this.mnuStory.Text = "Poveste";

            this.mnuValidate.Name = "mnuValidate"; this.mnuValidate.Text = "Validează";
            this.mnuValidate.Click += new System.EventHandler(this.OnValidate);

            // splitter
            this.splitter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitter.BackColor = System.Drawing.Color.FromArgb(20, 20, 20);
            this.splitter.Location = new System.Drawing.Point(0, 24);
            this.splitter.Name = "splitter";
            this.splitter.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.splitter.Panel1.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            this.splitter.Panel1.Controls.Add(this.treeView);
            this.splitter.Panel2.BackColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.splitter.Panel2.Controls.Add(this.pnlEdit);
            this.splitter.Size = new System.Drawing.Size(1100, 700);
            this.splitter.SplitterDistance = 260;
            this.splitter.TabIndex = 1;

            // treeView
            this.treeView.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            this.treeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.treeView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(260, 700);
            this.treeView.TabIndex = 0;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.OnTreeSelect);

            // pnlEdit
            this.pnlEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEdit.Location = new System.Drawing.Point(0, 0);
            this.pnlEdit.Name = "pnlEdit";
            this.pnlEdit.Padding = new System.Windows.Forms.Padding(15);
            this.pnlEdit.Size = new System.Drawing.Size(836, 700);
            this.pnlEdit.TabIndex = 0;

            // lblStatus
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(15, 15, 15);
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblStatus.ForeColor = System.Drawing.Color.Silver;
            this.lblStatus.Height = 24;
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Text = " Gata.";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // EditorForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.ClientSize = new System.Drawing.Size(1100, 750);
            this.Controls.Add(this.splitter);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.lblStatus);
            this.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "EditorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Story Editor";

            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.splitter.Panel1.ResumeLayout(false);
            this.splitter.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitter)).EndInit();
            this.splitter.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.MenuStrip        menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuNewStory;
        private System.Windows.Forms.ToolStripMenuItem mnuOpen;
        private System.Windows.Forms.ToolStripSeparator mnuSep1;
        private System.Windows.Forms.ToolStripMenuItem mnuSave;
        private System.Windows.Forms.ToolStripMenuItem mnuSaveAs;
        private System.Windows.Forms.ToolStripSeparator mnuSep2;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuAddBlock;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuStory;
        private System.Windows.Forms.ToolStripMenuItem mnuValidate;
        private System.Windows.Forms.SplitContainer    splitter;
        private System.Windows.Forms.TreeView          treeView;
        private System.Windows.Forms.Panel             pnlEdit;
        private System.Windows.Forms.Label             lblStatus;
    }
}
