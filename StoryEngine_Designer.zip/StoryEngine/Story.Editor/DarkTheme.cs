using System.Drawing;
using System.Windows.Forms;

namespace Story.Editor
{
    internal class DarkMenuRenderer : ToolStripProfessionalRenderer
    {
        public DarkMenuRenderer() : base(new DarkColorTable()) { }
    }

    internal class DarkColorTable : ProfessionalColorTable
    {
        public override Color MenuItemSelected            => Color.FromArgb(60, 60, 80);
        public override Color MenuItemBorder              => Color.FromArgb(100, 100, 140);
        public override Color MenuBorder                  => Color.FromArgb(60, 60, 80);
        public override Color ToolStripDropDownBackground => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientBegin    => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientMiddle   => Color.FromArgb(25, 25, 25);
        public override Color ImageMarginGradientEnd      => Color.FromArgb(25, 25, 25);
    }
}
