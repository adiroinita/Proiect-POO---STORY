using System;
using System.Drawing;
using System.Windows.Forms;
using Story.Model;

namespace Story.Editor
{
    internal partial class MetadataPanel : UserControl
    {
        private readonly StoryDefinition _story;
        private readonly Action          _onChange;

        public MetadataPanel(StoryDefinition story, Action onChange)
        {
            _story    = story;
            _onChange = onChange;
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            txtTitle.Text = _story.Title;
            txtStart.Text = _story.StartBlock;
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
            _story.Title = txtTitle.Text;
            _onChange();
        }

        private void txtStart_TextChanged(object sender, EventArgs e)
        {
            _story.StartBlock = txtStart.Text;
            _onChange();
        }

        private void btnAddProperty_Click(object sender, EventArgs e)
        {
            _story.Properties.Add(new StatePropertyDefinition
            { Key = "new.property", HudLabel = "Nou", Min = 0, Max = 100, Initial = 0 });
            _onChange();
        }
    }
}
