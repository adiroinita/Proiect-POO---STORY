using System;
using System.Drawing;
using System.Windows.Forms;
using Story.Model;

namespace Story.Editor
{
    internal partial class PropertyPanel : UserControl
    {
        private readonly StatePropertyDefinition _prop;
        private readonly StoryDefinition         _story;
        private readonly Action                  _onChange;

        public PropertyPanel(StatePropertyDefinition prop, StoryDefinition story, Action onChange)
        {
            _prop     = prop;
            _story    = story;
            _onChange = onChange;
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            txtKey.Text          = _prop.Key;
            txtHud.Text          = _prop.HudLabel;
            numMin.Value         = (decimal)_prop.Min;
            numMax.Value         = (decimal)_prop.Max;
            numInit.Value        = (decimal)Math.Max(_prop.Min, Math.Min(_prop.Max, _prop.Initial));
            chkVisible.Checked   = _prop.VisibleInHud;
            numOrder.Value       = _prop.HudOrder;
            txtOnMin.Text        = _prop.OnMinBlock ?? "";
            txtOnMax.Text        = _prop.OnMaxBlock ?? "";
        }

        private void txtKey_TextChanged(object s, EventArgs e)   { _prop.Key      = txtKey.Text; _onChange(); }
        private void txtHud_TextChanged(object s, EventArgs e)   { _prop.HudLabel = txtHud.Text; _onChange(); }
        private void numMin_ValueChanged(object s, EventArgs e)  { _prop.Min      = (double)numMin.Value; _onChange(); }
        private void numMax_ValueChanged(object s, EventArgs e)  { _prop.Max      = (double)numMax.Value; _onChange(); }
        private void numInit_ValueChanged(object s, EventArgs e) { _prop.Initial  = (double)numInit.Value; _onChange(); }
        private void chkVisible_CheckedChanged(object s, EventArgs e) { _prop.VisibleInHud = chkVisible.Checked; _onChange(); }
        private void numOrder_ValueChanged(object s, EventArgs e) { _prop.HudOrder = (int)numOrder.Value; _onChange(); }
        private void txtOnMin_TextChanged(object s, EventArgs e) { _prop.OnMinBlock = string.IsNullOrWhiteSpace(txtOnMin.Text) ? null : txtOnMin.Text; _onChange(); }
        private void txtOnMax_TextChanged(object s, EventArgs e) { _prop.OnMaxBlock = string.IsNullOrWhiteSpace(txtOnMax.Text) ? null : txtOnMax.Text; _onChange(); }
    }
}
