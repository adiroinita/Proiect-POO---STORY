using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Story.Model;
using Story.Model.Effects;

namespace Story.Editor
{

    internal static class UiHelper
    {
        public static Label MakeLabel(string text, int x, int y)
        {
            return new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                AutoSize  = true,
                ForeColor = Color.Silver,
                Font      = new Font("Segoe UI", 9)
            };
        }

        public static TextBox MakeTextBox(int x, int y, int width, string value = "")
        {
            return new TextBox
            {
                Location  = new Point(x, y),
                Width     = width,
                Text      = value,
                BackColor = Color.FromArgb(45, 45, 45),
                ForeColor = Color.WhiteSmoke,
                BorderStyle = BorderStyle.FixedSingle,
                Font      = new Font("Segoe UI", 10)
            };
        }

        public static CheckBox MakeCheckBox(string text, int x, int y, bool val)
        {
            return new CheckBox
            {
                Text      = text,
                Location  = new Point(x, y),
                Checked   = val,
                ForeColor = Color.WhiteSmoke,
                Font      = new Font("Segoe UI", 10),
                AutoSize  = true
            };
        }

        public static NumericUpDown MakeNumeric(int x, int y, int w, double val, double min = 0, double max = 100)
        {
            return new NumericUpDown
            {
                Location      = new Point(x, y),
                Width         = w,
                Minimum       = (decimal)min,
                Maximum       = (decimal)max,
                Value         = (decimal)Math.Max(min, Math.Min(max, val)),
                BackColor     = Color.FromArgb(45, 45, 45),
                ForeColor     = Color.WhiteSmoke,
                BorderStyle   = BorderStyle.FixedSingle,
                Font          = new Font("Segoe UI", 10),
                DecimalPlaces = 0
            };
        }

        public static Button MakeButton(string text, int x, int y, Action onClick)
        {
            var btn = new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                AutoSize  = true,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 50, 80),
                ForeColor = Color.WhiteSmoke,
                Font      = new Font("Segoe UI", 9)
            };
            btn.FlatAppearance.BorderColor = Color.FromArgb(80, 80, 120);
            btn.Click += (_, _) => onClick();
            return btn;
        }

        public static Label MakeTitle(string text)
        {
            return new Label
            {
                Text      = text,
                AutoSize  = true,
                Font      = new Font("Segoe UI", 13, FontStyle.Bold),
                ForeColor = Color.Gold,
                Margin    = new Padding(0, 0, 0, 12)
            };
        }
    }

    internal class MetadataPanel : Panel
    {
        private readonly StoryDefinition _story;
        private readonly Action          _onChange;

        public MetadataPanel(StoryDefinition story, Action onChange)
        {
            _story    = story;
            _onChange = onChange;
            BackColor = Color.FromArgb(30, 30, 30);
            Build();
        }

        private void Build()
        {
            Controls.Clear();
            int y = 10;

            Controls.Add(UiHelper.MakeTitle("Metadate poveste") with { Location = new Point(0, y) });
            y += 40;

            Controls.Add(UiHelper.MakeLabel("Titlu:", 0, y));
            var txtTitle = UiHelper.MakeTextBox(80, y, 300, _story.Title);
            txtTitle.TextChanged += (_, _) => { _story.Title = txtTitle.Text; _onChange(); };
            Controls.Add(txtTitle);
            y += 35;

            Controls.Add(UiHelper.MakeLabel("Start bloc:", 0, y));
            var txtStart = UiHelper.MakeTextBox(100, y, 250, _story.StartBlock);
            txtStart.TextChanged += (_, _) => { _story.StartBlock = txtStart.Text; _onChange(); };
            Controls.Add(txtStart);
            y += 45;

            Controls.Add(UiHelper.MakeButton("+ Proprietate", 0, y, () =>
            {
                _story.Properties.Add(new StatePropertyDefinition
                { Key = "new.property", HudLabel = "Nou", Min = 0, Max = 100, Initial = 0 });
                _onChange();
            }));
        }
    }

    internal class PropertyPanel : Panel
    {
        public PropertyPanel(StatePropertyDefinition prop, StoryDefinition story, Action onChange)
        {
            BackColor = Color.FromArgb(30, 30, 30);
            AutoScroll = true;

            int y = 10;
            Controls.Add(UiHelper.MakeTitle("Proprietate") with { Location = new Point(0, y) }); y += 40;

            Controls.Add(UiHelper.MakeLabel("Cheie:", 0, y));
            var txtKey = UiHelper.MakeTextBox(80, y, 220, prop.Key);
            txtKey.TextChanged += (_, _) => { prop.Key = txtKey.Text; onChange(); };
            Controls.Add(txtKey); y += 35;

            Controls.Add(UiHelper.MakeLabel("Etichetă HUD:", 0, y));
            var txtHud = UiHelper.MakeTextBox(120, y, 180, prop.HudLabel);
            txtHud.TextChanged += (_, _) => { prop.HudLabel = txtHud.Text; onChange(); };
            Controls.Add(txtHud); y += 35;

            Controls.Add(UiHelper.MakeLabel("Min:", 0, y));
            var numMin = UiHelper.MakeNumeric(40, y, 80, prop.Min, -99999, 99999);
            numMin.ValueChanged += (_, _) => { prop.Min = (double)numMin.Value; onChange(); };
            Controls.Add(numMin);

            Controls.Add(UiHelper.MakeLabel("Max:", 150, y));
            var numMax = UiHelper.MakeNumeric(190, y, 80, prop.Max, -99999, 99999);
            numMax.ValueChanged += (_, _) => { prop.Max = (double)numMax.Value; onChange(); };
            Controls.Add(numMax);

            Controls.Add(UiHelper.MakeLabel("Inițial:", 290, y));
            var numInit = UiHelper.MakeNumeric(340, y, 80, prop.Initial, prop.Min, prop.Max);
            numInit.ValueChanged += (_, _) => { prop.Initial = (double)numInit.Value; onChange(); };
            Controls.Add(numInit);
            y += 35;

            var chkVis = UiHelper.MakeCheckBox("Vizibil în HUD", 0, y, prop.VisibleInHud);
            chkVis.CheckedChanged += (_, _) => { prop.VisibleInHud = chkVis.Checked; onChange(); };
            Controls.Add(chkVis);

            Controls.Add(UiHelper.MakeLabel("Ordine HUD:", 200, y));
            var numOrder = UiHelper.MakeNumeric(300, y, 60, prop.HudOrder, 0, 999);
            numOrder.ValueChanged += (_, _) => { prop.HudOrder = (int)numOrder.Value; onChange(); };
            Controls.Add(numOrder);
            y += 35;

            Controls.Add(UiHelper.MakeLabel("onMinBlock:", 0, y));
            var txtOnMin = UiHelper.MakeTextBox(110, y, 200, prop.OnMinBlock ?? "");
            txtOnMin.TextChanged += (_, _) => { prop.OnMinBlock = string.IsNullOrWhiteSpace(txtOnMin.Text) ? null : txtOnMin.Text; onChange(); };
            Controls.Add(txtOnMin); y += 35;

            Controls.Add(UiHelper.MakeLabel("onMaxBlock:", 0, y));
            var txtOnMax = UiHelper.MakeTextBox(110, y, 200, prop.OnMaxBlock ?? "");
            txtOnMax.TextChanged += (_, _) => { prop.OnMaxBlock = string.IsNullOrWhiteSpace(txtOnMax.Text) ? null : txtOnMax.Text; onChange(); };
            Controls.Add(txtOnMax);
        }
    }

    internal class BlockPanel : Panel
    {
        private readonly StoryBlock       _block;
        private readonly StoryDefinition  _story;
        private readonly string           _zipPath;
        private readonly Action           _onChange;
        private DataGridView              _grid    = new();

        public BlockPanel(StoryBlock block, StoryDefinition story, string zipPath, Action onChange)
        {
            _block    = block;
            _story    = story;
            _zipPath  = zipPath;
            _onChange = onChange;
            BackColor = Color.FromArgb(30, 30, 30);
            AutoScroll = true;
            Build();
        }

        private void Build()
        {
            Controls.Clear();
            int y = 10;

            Controls.Add(UiHelper.MakeTitle("Bloc") with { Location = new Point(0, y) }); y += 40;

            Controls.Add(UiHelper.MakeLabel("ID:", 0, y));
            var txtId = UiHelper.MakeTextBox(40, y, 280, _block.Id);
            txtId.TextChanged += (_, _) => { _block.Id = txtId.Text; _onChange(); };
            Controls.Add(txtId); y += 35;

            var chkFinal = UiHelper.MakeCheckBox("Bloc final (sfârşit poveste)", 0, y, _block.IsFinal);
            chkFinal.CheckedChanged += (_, _) => { _block.IsFinal = chkFinal.Checked; _onChange(); };
            Controls.Add(chkFinal); y += 35;

            Controls.Add(UiHelper.MakeLabel("Text narativ:", 0, y)); y += 20;
            var rtb = new RichTextBox
            {
                Location    = new Point(0, y),
                Width       = 500,
                Height      = 120,
                Text        = _block.Text,
                BackColor   = Color.FromArgb(45, 45, 45),
                ForeColor   = Color.WhiteSmoke,
                BorderStyle = BorderStyle.FixedSingle,
                Font        = new Font("Segoe UI", 10)
            };
            rtb.TextChanged += (_, _) => { _block.Text = rtb.Text; _onChange(); };
            Controls.Add(rtb); y += 135;

            Controls.Add(UiHelper.MakeLabel("Imagine fundal:", 0, y));
            var txtImg = UiHelper.MakeTextBox(130, y, 250, _block.BackgroundImage ?? "");
            txtImg.TextChanged += (_, _) => { _block.BackgroundImage = string.IsNullOrWhiteSpace(txtImg.Text) ? null : txtImg.Text; _onChange(); };
            Controls.Add(txtImg);
            Controls.Add(UiHelper.MakeButton("Browse...", 390, y, () =>
            {
                using var dlg = new OpenFileDialog { Filter = "Imagini|*.jpg;*.jpeg;*.png;*.bmp" };
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    txtImg.Text = "images/" + Path.GetFileName(dlg.FileName);
                }
            }));
            y += 45;

            Controls.Add(UiHelper.MakeTitle("Decizii") with { Location = new Point(0, y) }); y += 35;

            Controls.Add(UiHelper.MakeButton("+ Adaugă decizie", 0, y, AddDecision));
            Controls.Add(UiHelper.MakeButton("✏ Editează", 140, y, EditSelected));
            Controls.Add(UiHelper.MakeButton("✕ Șterge",   220, y, DeleteSelected));
            y += 35;

            _grid = BuildDecisionGrid();
            _grid.Location = new Point(0, y);
            _grid.Width    = 520;
            _grid.Height   = 200;
            Controls.Add(_grid);
        }

        private DataGridView BuildDecisionGrid()
        {
            var grid = new DataGridView
            {
                BackgroundColor      = Color.FromArgb(35, 35, 35),
                GridColor            = Color.FromArgb(60, 60, 60),
                DefaultCellStyle     = { BackColor = Color.FromArgb(40, 40, 40), ForeColor = Color.WhiteSmoke },
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(25,25,25), ForeColor = Color.Gold },
                AutoSizeColumnsMode  = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode        = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly             = true,
                AllowUserToAddRows   = false,
                BorderStyle          = BorderStyle.None,
                RowHeadersVisible    = false
            };

            grid.Columns.Add("text",   "Text decizie");
            grid.Columns.Add("target", "Bloc țintă");
            grid.Columns.Add("cond",   "Condiție");
            grid.Columns.Add("effects","Efecte");

            RefreshGrid(grid);
            return grid;
        }

        private void RefreshGrid(DataGridView grid)
        {
            grid.Rows.Clear();
            foreach (var dec in _block.Decisions)
            {
                string cond = dec.Condition is null ? "-" : "DA";
                string eff  = dec.Effects.Count == 0 ? "-" : $"{dec.Effects.Count} efect(e)";
                grid.Rows.Add(dec.Text, dec.TargetBlock, cond, eff);
            }
        }

        private void AddDecision()
        {
            var dec = new DecisionDefinition { Text = "Decizie nouă", TargetBlock = "intro.start" };
            _block.Decisions.Add(dec);
            using var dlg = new DecisionDialog(dec, _story);
            dlg.ShowDialog();
            _onChange();
            RefreshGrid(_grid);
        }

        private void EditSelected()
        {
            if (_grid.SelectedRows.Count == 0) return;
            int idx = _grid.SelectedRows[0].Index;
            if (idx < 0 || idx >= _block.Decisions.Count) return;
            using var dlg = new DecisionDialog(_block.Decisions[idx], _story);
            dlg.ShowDialog();
            _onChange();
            RefreshGrid(_grid);
        }

        private void DeleteSelected()
        {
            if (_grid.SelectedRows.Count == 0) return;
            int idx = _grid.SelectedRows[0].Index;
            if (idx < 0 || idx >= _block.Decisions.Count) return;
            _block.Decisions.RemoveAt(idx);
            _onChange();
            RefreshGrid(_grid);
        }
    }

    internal class DecisionDialog : Form
    {
        private readonly DecisionDefinition _dec;
        private readonly StoryDefinition    _story;

        public DecisionDialog(DecisionDefinition dec, StoryDefinition story)
        {
            _dec   = dec;
            _story = story;
            Build();
        }

        private void Build()
        {
            Text        = "Editare decizie";
            Size        = new Size(600, 550);
            MinimumSize = new Size(500, 450);
            BackColor   = Color.FromArgb(30, 30, 30);
            ForeColor   = Color.WhiteSmoke;
            StartPosition = FormStartPosition.CenterParent;

            int y = 10;

            Controls.Add(UiHelper.MakeLabel("Text decizie:", 10, y));
            var txtText = UiHelper.MakeTextBox(130, y, 430, _dec.Text);
            txtText.TextChanged += (_, _) => _dec.Text = txtText.Text;
            Controls.Add(txtText); y += 35;

            Controls.Add(UiHelper.MakeLabel("Bloc țintă:", 10, y));
            var txtTarget = UiHelper.MakeTextBox(130, y, 280, _dec.TargetBlock);
            txtTarget.TextChanged += (_, _) => _dec.TargetBlock = txtTarget.Text;
            Controls.Add(txtTarget); y += 35;

            Controls.Add(UiHelper.MakeLabel("Iconiță:", 10, y));
            var txtIcon = UiHelper.MakeTextBox(130, y, 280, _dec.Icon ?? "");
            txtIcon.TextChanged += (_, _) => _dec.Icon = string.IsNullOrWhiteSpace(txtIcon.Text) ? null : txtIcon.Text;
            Controls.Add(txtIcon); y += 45;

            Controls.Add(UiHelper.MakeTitle("Efecte") with { Location = new Point(10, y) }); y += 35;

            var gridEff = new DataGridView
            {
                Location             = new Point(10, y),
                Width                = 550,
                Height               = 130,
                BackgroundColor      = Color.FromArgb(35, 35, 35),
                DefaultCellStyle     = { BackColor = Color.FromArgb(40,40,40), ForeColor = Color.WhiteSmoke },
                ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(25,25,25), ForeColor = Color.Gold },
                AllowUserToAddRows   = true,
                BorderStyle          = BorderStyle.None,
                RowHeadersVisible    = false
            };

            var colType = new DataGridViewComboBoxColumn { Name = "type", HeaderText = "Tip", Width = 60 };
            colType.Items.AddRange("ADD", "SET");

            gridEff.Columns.Add(colType);
            gridEff.Columns.Add(new DataGridViewTextBoxColumn { Name = "prop",  HeaderText = "Proprietate", Width = 200 });
            gridEff.Columns.Add(new DataGridViewTextBoxColumn { Name = "value", HeaderText = "Valoare",     Width = 80  });

            foreach (var eff in _dec.Effects)
                gridEff.Rows.Add(eff.Type.ToString(), eff.Property, eff.Value);

            Controls.Add(gridEff); y += 145;

            Controls.Add(UiHelper.MakeTitle("Condiție (JSON)") with { Location = new Point(10, y) }); y += 35;
            var txtCond = new RichTextBox
            {
                Location    = new Point(10, y),
                Width       = 550,
                Height      = 80,
                BackColor   = Color.FromArgb(45, 45, 45),
                ForeColor   = Color.LightGreen,
                Font        = new Font("Consolas", 9),
                Text        = _dec.Condition is null ? "" :
                              System.Text.Json.JsonSerializer.Serialize(_dec.Condition,
                                  new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
            Controls.Add(txtCond); y += 95;

            var btnOk = UiHelper.MakeButton("OK", 10, y, () =>
            {
                
                _dec.Effects.Clear();
                foreach (DataGridViewRow row in gridEff.Rows)
                {
                    if (row.IsNewRow) continue;
                    if (row.Cells["prop"].Value is not string prop || string.IsNullOrWhiteSpace(prop)) continue;
                    var type = row.Cells["type"].Value?.ToString() == "SET" ? EffectType.SET : EffectType.ADD;
                    double.TryParse(row.Cells["value"].Value?.ToString(), out double val);
                    _dec.Effects.Add(new EffectDefinition { Type = type, Property = prop, Value = val });
                }
                DialogResult = DialogResult.OK;
                Close();
            });

            Controls.Add(btnOk);
            Controls.Add(UiHelper.MakeButton("Anulează", 90, y, () => { DialogResult = DialogResult.Cancel; Close(); }));
        }
    }
}
